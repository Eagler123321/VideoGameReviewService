document.addEventListener('DOMContentLoaded', function () {
    // === AVATAR UPLOAD ===
    const avatarInput = document.getElementById('avatar-input');
    const avatarImg = document.getElementById('avatarImg');

    if (avatarInput && avatarImg) {
        avatarInput.addEventListener('change', function () {
            const file = this.files[0];
            if (!file) return;

            if (!file.type.startsWith('image/')) {
                Toast.error('Ошибка', 'Выберите файл изображения');
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                Toast.error('Ошибка', 'Файл слишком большой. Максимум 5 МБ');
                return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
                avatarImg.src = e.target.result;
                Toast.success('Аватар обновлён', 'Не забудьте сохранить изменения');
            };
            reader.readAsDataURL(file);
        });
    }
});

function saveProfile(e) {
    e.preventDefault();

    const nickname = document.getElementById('nickname').value.trim();
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    if (!nickname || nickname.length < 2) {
        Toast.error('Ошибка', 'Отображаемое имя должно содержать минимум 2 символа');
        return;
    }
    if (!username || username.length < 3) {
        Toast.error('Ошибка', 'Имя пользователя должно содержать минимум 3 символа');
        return;
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        Toast.error('Ошибка', 'Введите корректный email-адрес');
        return;
    }
    if (password && password.length < 6) {
        Toast.error('Ошибка', 'Пароль должен содержать минимум 6 символов');
        return;
    }

    Toast.success('Профиль сохранён', 'Ваши данные успешно обновлены');
}
