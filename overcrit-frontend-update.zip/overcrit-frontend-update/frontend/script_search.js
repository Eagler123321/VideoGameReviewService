document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('search-main');
    const navbarSearch = document.getElementById('navbar-search');
    const gamesGrid = document.getElementById('gamesGrid');
    const noResults = document.getElementById('no-results');
    const resultsTitle = document.getElementById('results-title');
    const resultsCount = document.getElementById('results-count');
    const resetBtn = document.getElementById('reset-filters');

    let activeGenre = '';
    let activeSort = 'rating-desc';
    let activeRating = 0;
    let searchQuery = '';

    // === DROPDOWN LOGIC ===
    function setupDropdown(dropdownId, btnId, menuId, onSelect) {
        const dropdown = document.getElementById(dropdownId);
        const btn = document.getElementById(btnId);
        const menu = document.getElementById(menuId);

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            document.querySelectorAll('.dropdown').forEach(d => {
                if (d !== dropdown) d.classList.remove('active');
            });
            dropdown.classList.toggle('active');
        });

        menu.querySelectorAll('.dropdown-item').forEach(item => {
            item.addEventListener('click', function () {
                menu.querySelectorAll('.dropdown-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                onSelect(this.dataset.value, this.textContent.trim());
                dropdown.classList.remove('active');
                applyFilters();
            });
        });
    }

    setupDropdown('dropdown-genre', 'genre-btn', 'genre-menu', (val, label) => {
        activeGenre = val;
        document.getElementById('genre-btn').childNodes[0].textContent = label + ' ';
    });

    setupDropdown('dropdown-sort', 'sort-btn', 'sort-menu', (val, label) => {
        activeSort = val;
        document.getElementById('sort-btn').childNodes[0].textContent = label + ' ';
    });

    setupDropdown('dropdown-rating', 'rating-btn', 'rating-menu', (val, label) => {
        activeRating = parseInt(val, 10);
        document.getElementById('rating-btn').childNodes[0].textContent = label + ' ';
    });

    // Close dropdowns on outside click
    document.addEventListener('click', function () {
        document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('active'));
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('active'));
        }
    });

    // === SEARCH INPUT ===
    searchInput.addEventListener('input', function () {
        searchQuery = this.value.trim().toLowerCase();
        applyFilters();
    });

    navbarSearch.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            searchQuery = this.value.trim().toLowerCase();
            searchInput.value = this.value;
            applyFilters();
        }
    });

    // === RESET ===
    resetBtn.addEventListener('click', function () {
        activeGenre = '';
        activeSort = 'rating-desc';
        activeRating = 0;
        searchQuery = '';
        searchInput.value = '';
        navbarSearch.value = '';

        document.getElementById('genre-btn').childNodes[0].textContent = 'Все жанры ';
        document.getElementById('sort-btn').childNodes[0].textContent = 'Высшая оценка ';
        document.getElementById('rating-btn').childNodes[0].textContent = 'Любой рейтинг ';

        document.querySelectorAll('.dropdown-item').forEach(item => item.classList.remove('active'));
        document.querySelectorAll('#genre-menu .dropdown-item')[0].classList.add('active');
        document.querySelectorAll('#sort-menu .dropdown-item')[0].classList.add('active');
        document.querySelectorAll('#rating-menu .dropdown-item')[0].classList.add('active');

        applyFilters();
        Toast.info('Фильтры сброшены', 'Показаны все игры');
    });

    // === FILTER + SORT LOGIC ===
    function applyFilters() {
        const cards = Array.from(gamesGrid.querySelectorAll('.game-card'));

        let visible = cards.filter(card => {
            const title = card.dataset.title.toLowerCase();
            const genre = card.dataset.genre;
            const rating = parseInt(card.dataset.rating, 10);

            const matchSearch = !searchQuery || title.includes(searchQuery);
            const matchGenre = !activeGenre || genre === activeGenre;
            const matchRating = rating >= activeRating;

            return matchSearch && matchGenre && matchRating;
        });

        // Sort
        visible.sort((a, b) => {
            switch (activeSort) {
                case 'rating-desc': return parseInt(b.dataset.rating) - parseInt(a.dataset.rating);
                case 'rating-asc':  return parseInt(a.dataset.rating) - parseInt(b.dataset.rating);
                case 'year-desc':   return parseInt(b.dataset.year) - parseInt(a.dataset.year);
                case 'year-asc':    return parseInt(a.dataset.year) - parseInt(b.dataset.year);
                case 'name-asc':    return a.dataset.title.localeCompare(b.dataset.title, 'ru');
                default: return 0;
            }
        });

        // Hide all first
        cards.forEach(card => {
            card.style.display = 'none';
            card.style.order = '';
        });

        // Show visible in sorted order
        visible.forEach((card, i) => {
            card.style.display = '';
            card.style.order = i;
        });

        // Show/hide no-results
        if (visible.length === 0) {
            noResults.style.display = 'flex';
            resultsTitle.textContent = 'Ничего не найдено';
            resultsCount.textContent = '';
        } else {
            noResults.style.display = 'none';
            const q = searchQuery ? `«${searchQuery}»` : '';
            resultsTitle.textContent = q ? `Результаты для ${q}` : 'Все игры';
            resultsCount.textContent = `${visible.length} ${pluralGames(visible.length)}`;
        }
    }

    function pluralGames(n) {
        if (n % 10 === 1 && n % 100 !== 11) return 'игра';
        if ([2,3,4].includes(n % 10) && ![12,13,14].includes(n % 100)) return 'игры';
        return 'игр';
    }

    applyFilters();
});
