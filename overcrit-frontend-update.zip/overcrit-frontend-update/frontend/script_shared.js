/* ========================================
   ОБЩИЙ МОДУЛЬ: TOAST + FOOTER + MODALS
   ======================================== */

// === TOAST SYSTEM ===
const Toast = {
    container: null,

    init() {
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.className = 'toast-container';
            document.body.appendChild(this.container);
        }
    },

    show(type, title, message, duration = 4000) {
        this.init();

        const icons = {
            success: `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>`,
            error:   `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
            info:    `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
        };

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            ${icons[type] || icons.info}
            <div class="toast-body">
                ${title ? `<div class="toast-title">${title}</div>` : ''}
                ${message ? `<div class="toast-message">${message}</div>` : ''}
            </div>
            <button class="toast-close" aria-label="Закрыть">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        `;

        this.container.appendChild(toast);

        toast.querySelector('.toast-close').addEventListener('click', () => this._dismiss(toast));

        const timer = setTimeout(() => this._dismiss(toast), duration);
        toast._timer = timer;

        return toast;
    },

    success(title, message, duration) { return this.show('success', title, message, duration); },
    error(title, message, duration)   { return this.show('error',   title, message, duration); },
    info(title, message, duration)    { return this.show('info',    title, message, duration); },

    _dismiss(toast) {
        clearTimeout(toast._timer);
        toast.classList.add('toast-exit');
        toast.addEventListener('animationend', () => toast.remove(), { once: true });
    }
};

// === FOOTER HTML ===
function renderFooter() {
    const footer = document.createElement('footer');
    footer.className = 'site-footer';
    footer.innerHTML = `
        <div class="footer-inner">
            <div class="footer-brand">
                <img src="Images/Vercrit.png" alt="Vercrit" class="footer-logo">
                <p class="footer-tagline">Платформа для публикации, просмотра и анализа рецензий на видеоигры.</p>
            </div>

            <nav class="footer-nav">
                <div class="footer-nav-title">Навигация</div>
                <a href="Main_page.html">Главная</a>
                <a href="Search_page.html">Поиск игр</a>
                <a href="Login_and_registration.html">Войти / Регистрация</a>
                <a href="Profile.html">Профиль</a>
            </nav>

            <nav class="footer-nav">
                <div class="footer-nav-title">О проекте</div>
                <button onclick="openAboutModal()">О нас</button>
                <button onclick="openContactModal()">Связь с нами</button>
                <button onclick="openPrivacyModal()">Политика конфиденциальности</button>
            </nav>
        </div>
        <div class="footer-bottom">
            © 2026 Vercrit. Все права защищены.
        </div>
    `;
    document.body.appendChild(footer);
}

// === MODALS ===
function createModal(id, title, contentHTML) {
    if (document.getElementById(id)) return;
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay modal-hidden';
    overlay.id = id;
    overlay.innerHTML = `
        <div class="modal-box" role="dialog" aria-modal="true" aria-labelledby="${id}-title">
            <button class="modal-close" onclick="closeModal('${id}')" aria-label="Закрыть">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
            <h2 class="modal-title" id="${id}-title">${title}</h2>
            <div class="modal-body">${contentHTML}</div>
        </div>
    `;
    document.body.appendChild(overlay);

    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) closeModal(id);
    });
    document.addEventListener('keydown', function handler(e) {
        if (e.key === 'Escape' && !overlay.classList.contains('modal-hidden')) {
            closeModal(id);
        }
    });
}

function openModal(id) {
    const overlay = document.getElementById(id);
    if (overlay) overlay.classList.remove('modal-hidden');
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    const overlay = document.getElementById(id);
    if (overlay) overlay.classList.add('modal-hidden');
    document.body.style.overflow = '';
}

function openAboutModal()   { openModal('modal-about'); }
function openContactModal() { openModal('modal-contact'); }
function openPrivacyModal() { openModal('modal-privacy'); }

// === INIT MODALS ===
function initModals() {
    createModal('modal-about', 'О нас', `
        <p><strong style="color:#fff">Vercrit</strong> — это независимая платформа для честных рецензий на видеоигры, созданная игроками для игроков.</p>
        <p>Наша миссия — помочь геймерам находить игры, которые действительно стоят их времени. Мы верим, что лучшие рецензии пишут те, кто по-настоящему любит игры.</p>
        <p>На платформе каждый может делиться своим мнением, оценивать игры по нескольким критериям — сюжету, геймплею, графике и вайбу — и читать обзоры от сообщества.</p>
        <p style="color:#555;font-size:13px;margin-top:16px;">Версия: 1.0.0 &nbsp;·&nbsp; © 2026 Vercrit</p>
    `);

    createModal('modal-contact', 'Связь с нами', `
        <p>Есть вопрос, предложение или нашли баг? Напишите нам — мы читаем каждое сообщение.</p>
        <form class="contact-form" id="contact-form" onsubmit="submitContactForm(event)">
            <div>
                <label for="contact-email">Ваша почта</label>
                <input type="email" id="contact-email" placeholder="example@gmail.com" required>
            </div>
            <div>
                <label for="contact-message">Комментарий</label>
                <textarea id="contact-message" placeholder="Ваше сообщение..." required></textarea>
            </div>
            <button type="submit" class="contact-submit-btn">Отправить</button>
        </form>
    `);

    createModal('modal-privacy', 'Политика конфиденциальности', `
        <p><strong style="color:#fff">Последнее обновление: 1 января 2026 года</strong></p>
        <p>Настоящая Политика конфиденциальности описывает, как Vercrit собирает, использует и защищает персональные данные пользователей платформы.</p>
        <p><strong style="color:#ccc">1. Сбор данных</strong><br>Мы собираем данные, которые вы предоставляете при регистрации: имя пользователя, адрес электронной почты и пароль. Также мы автоматически фиксируем технические данные о вашем устройстве и браузере для обеспечения корректной работы сервиса.</p>
        <p><strong style="color:#ccc">2. Использование данных</strong><br>Собранные данные используются исключительно для обеспечения работы платформы, персонализации контента и улучшения пользовательского опыта. Мы не продаём и не передаём ваши данные третьим лицам.</p>
        <p><strong style="color:#ccc">3. Хранение данных</strong><br>Ваши данные хранятся на защищённых серверах. Мы принимаем разумные технические и организационные меры для предотвращения несанкционированного доступа.</p>
        <p><strong style="color:#ccc">4. Права пользователя</strong><br>Вы вправе запросить доступ к своим данным, их исправление или удаление, обратившись к нам через форму «Связь с нами».</p>
        <p><strong style="color:#ccc">5. Изменения политики</strong><br>Мы оставляем за собой право вносить изменения в настоящую политику. Актуальная версия всегда доступна на этой странице.</p>
        <p style="color:#555;font-size:13px;margin-top:16px;">© 2026 Vercrit. Все права защищены.</p>
    `);
}

function submitContactForm(e) {
    e.preventDefault();
    const email = document.getElementById('contact-email').value.trim();
    const message = document.getElementById('contact-message').value.trim();
    if (!email || !message) {
        Toast.error('Ошибка', 'Заполните все поля формы');
        return;
    }
    closeModal('modal-contact');
    document.getElementById('contact-form').reset();
    Toast.success('Сообщение отправлено', 'Мы ответим вам в ближайшее время.');
}

// === AUTO INIT ===
document.addEventListener('DOMContentLoaded', function() {
    renderFooter();
    initModals();
});
