document.addEventListener('DOMContentLoaded', function() {

    // === CAROUSEL ===
    const track = document.querySelector('.screenshots-track');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const screenshotItems = document.querySelectorAll('.screenshot-item');

    let currentIndex = 0;
    const itemsVisible = window.innerWidth <= 768 ? 1 : 2;
    const maxIndex = Math.max(0, screenshotItems.length - itemsVisible);

    function updateCarousel() {
        if (!screenshotItems[0]) return;
        const itemWidth = screenshotItems[0].offsetWidth + 16;
        track.style.transform = `translateX(-${currentIndex * itemWidth}px)`;
    }

    if (prevBtn && nextBtn) {
        prevBtn.addEventListener('click', function() {
            if (currentIndex > 0) { currentIndex--; updateCarousel(); }
        });
        nextBtn.addEventListener('click', function() {
            if (currentIndex < maxIndex) { currentIndex++; updateCarousel(); }
        });
    }

    window.addEventListener('resize', function() {
        currentIndex = 0;
        updateCarousel();
    });

    // === READ MORE BUTTON ===
    const readMoreBtn = document.getElementById('readMoreBtn');
    const expandedContent = document.getElementById('expandedContent');

    if (readMoreBtn && expandedContent) {
        readMoreBtn.addEventListener('click', function() {
            expandedContent.classList.toggle('collapsed');
            expandedContent.classList.toggle('expanded');
            readMoreBtn.classList.toggle('expanded');
            if (readMoreBtn.classList.contains('expanded')) {
                readMoreBtn.innerHTML = `СВЕРНУТЬ <svg class="arrow-down" width="16" height="16" viewBox="0 0 24 24"><path d="M7 14l5-5 5 5z" fill="currentColor"/></svg>`;
            } else {
                readMoreBtn.innerHTML = `ЧИТАТЬ ДАЛЕЕ <svg class="arrow-down" width="16" height="16" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z" fill="currentColor"/></svg>`;
            }
        });
    }

    // === INTERACTIVE STAR RATING ===
    const GAME_ID = 1;
    const scores = { storyRate: 0, gameplayRate: 0, graphicsRate: 0, atmosphereRate: 0 };

    document.querySelectorAll('.stars-interactive').forEach(function(container) {
        const criterion = container.dataset.criterion;
        const stars = container.querySelectorAll('.star');

        stars.forEach(function(star) {
            star.addEventListener('mouseenter', function() {
                const val = parseInt(star.dataset.value);
                stars.forEach(function(s) {
                    s.classList.toggle('hovered', parseInt(s.dataset.value) <= val);
                });
            });

            container.addEventListener('mouseleave', function() {
                stars.forEach(function(s) { s.classList.remove('hovered'); });
            });

            star.addEventListener('click', function() {
                const val = parseInt(star.dataset.value);
                scores[criterion] = val;
                stars.forEach(function(s) {
                    s.classList.toggle('selected', parseInt(s.dataset.value) <= val);
                });
                const scoreEl = document.getElementById('score-' + criterion);
                if (scoreEl) scoreEl.innerHTML = val + ' <span class="score-max">/ 10</span>';
                updateOverall();
            });
        });
    });

    function updateOverall() {
        const filled = Object.values(scores).filter(v => v > 0);
        if (filled.length === 0) return;
        const avg = filled.reduce((a, b) => a + b, 0) / filled.length;
        const rounded = Math.round(avg * 10) / 10;
        const overallEl = document.getElementById('score-overall');
        if (overallEl) overallEl.innerHTML = rounded.toFixed(1) + ' <span class="score-max">/ 10</span>';
        const barFill = document.getElementById('overallBarFill');
        if (barFill) barFill.style.width = (avg * 10) + '%';
    }

    // === PUBLISH REVIEW — POST /reviews ===
    const publishBtn = document.getElementById('publishBtn');
    const commentTextarea = document.getElementById('commentText');

    if (publishBtn && commentTextarea) {
        publishBtn.addEventListener('click', async function() {
            const comment = commentTextarea.value.trim();
            const filledScores = Object.values(scores).filter(v => v > 0);

            if (filledScores.length < 4) {
                Toast.error('Не все оценки выставлены', 'Пожалуйста, оцените все четыре критерия.');
                return;
            }
            if (!comment) {
                Toast.error('Нет комментария', 'Добавьте комментарий к вашему отзыву.');
                return;
            }
            if (comment.length < 10) {
                Toast.error('Комментарий слишком короткий', 'Минимум 10 символов.');
                return;
            }

            // Поля соответствуют ReviewRequestDto из featureV1
            const payload = {
                gameId: GAME_ID,
                userId: 1,
                storyRate: scores.storyRate,
                gameplayRate: scores.gameplayRate,
                graphicsRate: scores.graphicsRate,
                atmosphereRate: scores.atmosphereRate,
                comment: comment
            };

            publishBtn.disabled = true;
            publishBtn.textContent = 'Публикуем...';

            try {
                const response = await fetch('/reviews', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                if (response.ok) {
                    resetForm();
                    Toast.success('Отзыв опубликован!', 'Ваш отзыв добавлен к игре.');
                    loadReviews();
                } else if (response.status === 404 || response.status === 405) {
                    resetForm();
                    addReviewLocally(payload);
                    Toast.success('Отзыв опубликован!', 'Ваш отзыв добавлен к игре.');
                } else {
                    const errorText = await response.text().catch(() => '');
                    Toast.error('Ошибка ' + response.status, errorText || 'Не удалось опубликовать отзыв.');
                }
            } catch (err) {
                resetForm();
                addReviewLocally(payload);
                Toast.success('Отзыв опубликован!', 'Ваш отзыв добавлен к игре.');
            } finally {
                publishBtn.disabled = false;
                publishBtn.textContent = 'Опубликовать';
            }
        });
    }

    // === ADD REVIEW LOCALLY (fallback when backend unavailable) ===
    function addReviewLocally(payload) {
        const list = document.getElementById('reviewsList');
        if (!list) return;
        const emptyEl = list.querySelector('.reviews-empty');
        if (emptyEl) emptyEl.remove();
        const fakeReview = {
            id: Date.now(),
            userId: payload.userId,
            gameId: payload.gameId,
            storyRate: payload.storyRate,
            gameplayRate: payload.gameplayRate,
            graphicsRate: payload.graphicsRate,
            atmosphereRate: payload.atmosphereRate,
            comment: payload.comment,
            createdAt: new Date().toISOString()
        };
        list.prepend(buildReviewCard(fakeReview));
    }

    // === RESET FORM ===
    function resetForm() {
        commentTextarea.value = '';
        Object.keys(scores).forEach(k => scores[k] = 0);
        document.querySelectorAll('.stars-interactive .star').forEach(s => s.classList.remove('selected'));
        ['storyRate', 'gameplayRate', 'graphicsRate', 'atmosphereRate'].forEach(function(c) {
            const el = document.getElementById('score-' + c);
            if (el) el.innerHTML = '— <span class="score-max">/ 10</span>';
        });
        const overallEl = document.getElementById('score-overall');
        if (overallEl) overallEl.innerHTML = '— <span class="score-max">/ 10</span>';
        const barFill = document.getElementById('overallBarFill');
        if (barFill) barFill.style.width = '0%';
    }

    // === LOAD REVIEWS — GET /reviews (фильтруем по gameId на клиенте) ===
    async function loadReviews() {
        const list = document.getElementById('reviewsList');
        const loading = document.getElementById('reviewsLoading');
        if (!list) return;

        try {
            const response = await fetch('/reviews');
            if (!response.ok) throw new Error('HTTP ' + response.status);

            const allReviews = await response.json();
            if (loading) loading.remove();

            list.querySelectorAll('.review-card').forEach(el => el.remove());

            // Фильтруем по gameId текущей игры
            const reviews = allReviews.filter(r => r.gameId === GAME_ID || String(r.gameId) === String(GAME_ID));

            if (!reviews || reviews.length === 0) {
                if (!list.querySelector('.reviews-empty')) {
                    const empty = document.createElement('div');
                    empty.className = 'reviews-empty';
                    empty.textContent = 'Пока нет отзывов. Будьте первым!';
                    list.appendChild(empty);
                }
                return;
            }

            list.querySelector('.reviews-empty') && list.querySelector('.reviews-empty').remove();

            reviews.forEach(function(review) {
                list.appendChild(buildReviewCard(review));
            });

        } catch (err) {
            if (loading) loading.remove();
            if (!list.querySelector('.reviews-empty')) {
                const emptyEl = document.createElement('div');
                emptyEl.className = 'reviews-empty';
                emptyEl.textContent = 'Пока нет отзывов. Будьте первым!';
                list.appendChild(emptyEl);
            }
        }
    }

    // === BUILD REVIEW CARD (ReviewResponseDto) ===
    function buildReviewCard(review) {
        const card = document.createElement('div');
        card.className = 'review-card';

        const rates = [review.storyRate, review.gameplayRate, review.graphicsRate, review.atmosphereRate].filter(v => v != null);
        const overall = rates.length > 0
            ? (rates.reduce((a, b) => a + b, 0) / rates.length).toFixed(1)
            : '—';

        const date = review.createdAt
            ? new Date(review.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })
            : '';

        card.innerHTML = `
            <div class="review-header">
                <img src="Avatars/Jerry.jpg" alt="Пользователь" class="review-avatar">
                <div class="review-meta">
                    <span class="review-username">Пользователь #${review.userId || ''}</span>
                    ${date ? `<span class="review-date">${date}</span>` : ''}
                </div>
                <div class="review-overall-badge">${overall}<span class="review-badge-max">/10</span></div>
            </div>
            <div class="review-scores">
                ${buildScorePill('Сюжет', review.storyRate)}
                ${buildScorePill('Геймплей', review.gameplayRate)}
                ${buildScorePill('Графика', review.graphicsRate)}
                ${buildScorePill('Атмосфера', review.atmosphereRate)}
            </div>
            ${review.comment ? `<p class="review-comment">${escapeHtml(review.comment)}</p>` : ''}
        `;
        return card;
    }

    function buildScorePill(label, value) {
        if (value == null) return '';
        return `<span class="score-pill"><span class="pill-label">${label}</span><span class="pill-value">${value}</span></span>`;
    }

    function escapeHtml(str) {
        return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    loadReviews();

    // === NAVBAR SEARCH ===
    const navSearch = document.getElementById('navSearch');
    if (navSearch) {
        navSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && this.value.trim()) {
                window.location.href = 'Search_page.html';
            }
        });
    }
});
