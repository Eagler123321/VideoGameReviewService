document.addEventListener('DOMContentLoaded', function() {
    const searchGamesBtn = document.getElementById('searchGamesBtn');
    const mainSearchInput = document.getElementById('mainSearchInput');
    const navSearchInput = document.getElementById('navSearchInput');
    const gamesGrid = document.getElementById('gamesGrid');
    const sectionTitle = document.getElementById('sectionTitle');
    const noResultsMain = document.getElementById('noResultsMain');
    const settingsBtn = document.getElementById('settingsBtn');

    let activeGenre = '';
    let activeSort = 'rating-desc';
    let searchQuery = '';

    // === КНОПКА «ИСКАТЬ ИГРЫ» ===
    if (searchGamesBtn) {
        searchGamesBtn.addEventListener('click', function () {
            window.location.href = 'Search_page.html';
        });
    }

    // === NAVBAR SEARCH ===
    if (navSearchInput) {
        navSearchInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter' && this.value.trim()) {
                window.location.href = 'Search_page.html';
            }
        });
    }

    // === MAIN SEARCH (фильтр на месте) ===
    if (mainSearchInput) {
        mainSearchInput.addEventListener('input', function () {
            searchQuery = this.value.trim().toLowerCase();
            applyFilters();
        });
    }

    // === DROPDOWN LOGIC ===
    function setupDropdown(dropdownId, btnId, menuId, onSelect) {
        const dropdown = document.getElementById(dropdownId);
        const btn = document.getElementById(btnId);
        const menu = document.getElementById(menuId);
        if (!dropdown || !btn || !menu) return;

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            document.querySelectorAll('.dropdown').forEach(d => {
                if (d !== dropdown) d.classList.remove('active');
            });
            dropdown.classList.toggle('active');
        });

        menu.querySelectorAll('.dropdown-item-inline').forEach(item => {
            item.addEventListener('click', function () {
                menu.querySelectorAll('.dropdown-item-inline').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                onSelect(this.dataset.value, this.textContent.trim());
                dropdown.classList.remove('active');
                applyFilters();
            });
        });
    }

    setupDropdown('dropdown-genre', 'genre-btn', 'genre-menu', (val, label) => {
        activeGenre = val;
        const btn = document.getElementById('genre-btn');
        if (btn) btn.childNodes[0].textContent = label + ' ';
    });

    setupDropdown('dropdown-sort', 'sort-btn', 'sort-menu', (val, label) => {
        activeSort = val;
        const btn = document.getElementById('sort-btn');
        if (btn) btn.childNodes[0].textContent = label + ' ';
    });

    document.addEventListener('click', function () {
        document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('active'));
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('active'));
        }
    });

    // === SETTINGS BTN ===
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function () {
            Toast.info('Фильтры', 'Используйте выпадающие списки для фильтрации игр');
        });
    }

    // === FILTER + SORT ===
    function applyFilters() {
        if (!gamesGrid) return;
        const cards = Array.from(gamesGrid.querySelectorAll('.game-card'));

        let visible = cards.filter(card => {
            const title = card.dataset.title.toLowerCase();
            const genre = card.dataset.genre;
            const matchSearch = !searchQuery || title.includes(searchQuery);
            const matchGenre = !activeGenre || genre === activeGenre;
            return matchSearch && matchGenre;
        });

        visible.sort((a, b) => {
            switch (activeSort) {
                case 'rating-desc': return parseInt(b.dataset.rating) - parseInt(a.dataset.rating);
                case 'rating-asc':  return parseInt(a.dataset.rating) - parseInt(b.dataset.rating);
                case 'year-desc':   return parseInt(b.dataset.year) - parseInt(a.dataset.year);
                case 'year-asc':    return parseInt(a.dataset.year) - parseInt(b.dataset.year);
                default: return 0;
            }
        });

        cards.forEach(card => { card.style.display = 'none'; card.style.order = ''; });
        visible.forEach((card, i) => { card.style.display = ''; card.style.order = i; });

        if (noResultsMain) {
            noResultsMain.style.display = visible.length === 0 ? 'flex' : 'none';
        }
        if (sectionTitle) {
            sectionTitle.textContent = visible.length === 0
                ? 'Ничего не найдено'
                : (searchQuery || activeGenre ? 'Результаты фильтрации' : 'Высокооцененные игры');
        }
    }

    applyFilters();
});
