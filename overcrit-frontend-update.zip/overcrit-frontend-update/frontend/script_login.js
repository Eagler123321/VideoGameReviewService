function switchTab(tabName, btn) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(tabName).classList.add('active');
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    if (!email) {
        Toast.error('Ошибка входа', 'Введите почту или имя пользователя');
        return;
    }
    if (!password) {
        Toast.error('Ошибка входа', 'Введите пароль');
        return;
    }
    if (password.length < 4) {
        Toast.error('Ошибка входа', 'Пароль слишком короткий');
        return;
    }

    // Simulate login (replace with real API call)
    Toast.success('Вход выполнен', 'Добро пожаловать! Перенаправляем...');
    setTimeout(() => {
        window.location.href = 'Main_page.html';
    }, 1500);
}

function handleRegister(e) {
    e.preventDefault();
    const email = document.getElementById('reg-email').value.trim();
    const name = document.getElementById('reg-name').value.trim();
    const password = document.getElementById('reg-password').value;

    if (!email) {
        Toast.error('Ошибка регистрации', 'Введите адрес почты');
        return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        Toast.error('Ошибка регистрации', 'Введите корректный email-адрес');
        return;
    }
    if (!name || name.length < 3) {
        Toast.error('Ошибка регистрации', 'Имя должно содержать минимум 3 символа');
        return;
    }
    if (!password || password.length < 6) {
        Toast.error('Ошибка регистрации', 'Пароль должен содержать минимум 6 символов');
        return;
    }

    Toast.success('Регистрация успешна!', 'Аккаунт создан. Выполняем вход...');
    setTimeout(() => {
        window.location.href = 'Main_page.html';
    }, 1800);
}
